--
-- PostgreSQL database dump
--

\restrict TLdF7umSgJRuaglKt9wyHOZZWFfgMIhAisfmSaJajAEyTuYRS5PGtmKLH8HCXMC

-- Dumped from database version 16.16
-- Dumped by pg_dump version 16.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: urls; Type: TABLE; Schema: public; Owner: shortener_user
--

CREATE TABLE public.urls (
    id integer NOT NULL,
    short_code character varying(10) NOT NULL,
    original_url text NOT NULL,
    clicks integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.urls OWNER TO shortener_user;

--
-- Name: urls_id_seq; Type: SEQUENCE; Schema: public; Owner: shortener_user
--

CREATE SEQUENCE public.urls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.urls_id_seq OWNER TO shortener_user;

--
-- Name: urls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: shortener_user
--

ALTER SEQUENCE public.urls_id_seq OWNED BY public.urls.id;


--
-- Name: urls id; Type: DEFAULT; Schema: public; Owner: shortener_user
--

ALTER TABLE ONLY public.urls ALTER COLUMN id SET DEFAULT nextval('public.urls_id_seq'::regclass);


--
-- Data for Name: urls; Type: TABLE DATA; Schema: public; Owner: shortener_user
--

COPY public.urls (id, short_code, original_url, clicks, created_at) FROM stdin;
1	J6kOB1	https://github.com/	2	2026-11-17 13:26:45.874711
2	6TrBiE	https://example.com/	0	2026-11-17 13:38:50.923828
3	dMlz2T	https://example.com/	0	2026-11-17 13:38:51.070921
4	s2Fy2A	https://example.com/	0	2026-11-17 13:38:51.229195
5	7WRJPf	https://example.com/	0	2026-11-17 13:38:51.388872
6	upnxoI	https://example.com/	0	2026-11-17 13:38:51.544392
7	1XhPZV	https://example.com/	0	2026-11-17 13:38:51.696693
8	TiiBUS	https://example.com/	0	2026-11-17 13:38:51.838153
9	P48Cpu	https://example.com/	0	2026-11-17 13:38:51.983223
10	NcG0AV	https://example.com/	0	2026-11-17 13:38:52.142485
11	nR5wPB	https://example.com/	0	2026-11-17 13:38:52.294835
12	rSL9qW	https://example.com/	0	2026-11-17 13:38:52.454839
13	pEMfDO	https://example.com/	0	2026-11-17 13:38:52.616852
14	urnzG9	https://example.com/	0	2026-11-17 13:38:52.77345
15	zAvFr5	https://example.com/	0	2026-11-17 13:38:52.936005
16	Uhn5Ji	https://example.com/	0	2026-11-17 13:38:53.089871
17	Ins6Fe	https://example.com/	0	2026-11-17 13:38:53.244353
18	QDyUin	https://example.com/	0	2026-11-17 13:38:53.397661
19	KYtPZn	https://example.com/	0	2026-11-17 13:38:53.554594
20	eCDEni	https://example.com/	0	2026-11-17 13:38:53.707499
21	VS2fXX	https://example.com/	0	2026-11-17 13:38:53.862505
22	Yg7aTZ	https://example.com/	0	2026-11-17 13:38:54.02747
23	Zsgu4t	https://example.com/	0	2026-11-17 13:38:54.193627
24	sMQrLb	https://example.com/	0	2026-11-17 13:38:54.348629
25	Om14dv	https://example.com/	0	2026-11-17 13:38:54.503764
26	kYv18Q	https://example.com/	0	2026-11-17 13:38:54.658927
27	USNnIb	https://example.com/	0	2026-11-17 13:38:54.815801
28	JEmhE9	https://example.com/	0	2026-11-17 13:38:54.976429
29	bhxQ8d	https://example.com/	0	2026-11-17 13:38:55.135109
30	IE8YAJ	https://example.com/	0	2026-11-17 13:38:55.288565
31	tzkcsI	https://example.com/	0	2026-11-17 13:38:55.427515
32	mHAnP7	https://example.com/	0	2026-11-17 13:38:55.573494
33	O1j26e	https://example.com/	0	2026-11-17 13:38:55.732809
34	BwwdHZ	https://example.com/	0	2026-11-17 13:38:55.89489
35	vx21NJ	https://example.com/	0	2026-11-17 13:38:56.051938
36	FNbser	https://example.com/	0	2026-11-17 13:38:56.208276
37	zQQWeV	https://example.com/	0	2026-11-17 13:38:56.360231
38	Iw9Ibe	https://example.com/	0	2026-11-17 13:38:56.515673
39	7yTIjN	https://example.com/	0	2026-11-17 13:38:56.674592
40	iBIJnx	https://example.com/	0	2026-11-17 13:38:56.832223
41	w1xcCX	https://example.com/	0	2026-11-17 13:38:56.987134
42	gJ4i9f	https://example.com/	0	2026-11-17 13:38:57.144111
43	O46fBX	https://example.com/	0	2026-11-17 13:38:57.300262
44	BAAIHj	https://example.com/	0	2026-11-17 13:38:57.461662
45	6Nn9Dw	https://example.com/	0	2026-11-17 13:38:57.610953
46	Bfv5Q0	https://example.com/	0	2026-11-17 13:38:57.759155
47	3xqQIO	https://example.com/	0	2026-11-17 13:38:57.911865
48	vvR4OB	https://example.com/	0	2026-11-17 13:38:58.062643
49	eNdBvx	https://example.com/	0	2026-11-17 13:38:58.222964
50	WIxMn1	https://example.com/	0	2026-11-17 13:38:58.373742
51	5A2nvO	https://example.com/	0	2026-11-17 13:38:58.526635
52	ysveBs	https://example.com/	0	2026-11-17 13:38:58.687119
53	CBhATn	https://example.com/	0	2026-11-17 13:38:58.845717
54	cLD7hn	https://example.com/	0	2026-11-17 13:38:59.002938
55	TUKW9L	https://example.com/	0	2026-11-17 13:38:59.163617
56	f6ncla	https://example.com/	0	2026-11-17 13:38:59.316112
57	s3NgLJ	https://example.com/	0	2026-11-17 13:38:59.47856
58	7TBfUG	https://example.com/	0	2026-11-17 13:38:59.630353
59	SboY88	https://example.com/	0	2026-11-17 13:38:59.780865
60	m8ypKU	https://example.com/	0	2026-11-17 13:38:59.934242
61	oQvqZX	https://example.com/	0	2026-11-17 13:39:00.089892
62	xCUNhn	https://example.com/	0	2026-11-17 13:39:00.247073
63	h5qRMb	https://example.com/	0	2026-11-17 13:39:00.401485
64	EStyyJ	https://example.com/	0	2026-11-17 13:39:00.541325
65	99QtMb	https://example.com/	0	2026-11-17 13:39:00.683713
66	RKrVCJ	https://example.com/	0	2026-11-17 13:39:00.838172
67	aeJBl5	https://example.com/	0	2026-11-17 13:39:00.994506
68	FPDXj2	https://example.com/	0	2026-11-17 13:39:01.151101
69	BPKk9c	https://example.com/	0	2026-11-17 13:39:01.30631
70	Ara8ZI	https://example.com/	0	2026-11-17 13:39:01.461458
71	EPH67q	https://example.com/	0	2026-11-17 13:39:01.618146
72	bjMuN2	https://example.com/	0	2026-11-17 13:39:01.775321
73	MI0iX9	https://example.com/	0	2026-11-17 13:39:01.929632
74	lfqLOK	https://example.com/	0	2026-11-17 13:39:02.081267
75	v6Wnat	https://example.com/	0	2026-11-17 13:39:02.241042
76	m8tuzA	https://example.com/	0	2026-11-17 13:39:02.398783
77	KDMwZ2	https://example.com/	0	2026-11-17 13:39:02.559248
78	1hUdbf	https://example.com/	0	2026-11-17 13:39:02.716099
79	IBHcQf	https://example.com/	0	2026-11-17 13:39:02.873551
80	1zfmyD	https://example.com/	0	2026-11-17 13:39:03.031123
81	KtkVT9	https://example.com/	0	2026-11-17 13:39:03.188895
82	a0064i	https://example.com/	0	2026-11-17 13:39:03.348961
83	Scr4GW	https://example.com/	0	2026-11-17 13:39:03.507045
84	V3SiE8	https://example.com/	0	2026-11-17 13:39:03.663783
85	PO88zy	https://example.com/	0	2026-11-17 13:39:03.822388
86	KZprf8	https://example.com/	0	2026-11-17 13:39:03.978956
87	mcCObI	https://example.com/	0	2026-11-17 13:39:04.131868
88	rwND7v	https://example.com/	0	2026-11-17 13:39:04.291401
89	yEV5sW	https://example.com/	0	2026-11-17 13:39:04.45017
90	i3MfEF	https://example.com/	0	2026-11-17 13:39:04.604168
91	jQ64Oq	https://example.com/	0	2026-11-17 13:39:04.762026
92	p3bJGg	https://example.com/	0	2026-11-17 13:39:04.919187
93	YCaIpu	https://example.com/	0	2026-11-17 13:39:05.078267
94	miJmp7	https://example.com/	0	2026-11-17 13:39:05.237393
95	SURt9k	https://example.com/	0	2026-11-17 13:39:05.399969
96	3VURaH	https://example.com/	0	2026-11-17 13:39:05.556715
97	I0DOoe	https://example.com/	0	2026-11-17 13:39:05.71292
98	iL7MbI	https://example.com/	0	2026-11-17 13:39:05.864486
99	w23bMc	https://example.com/	0	2026-11-17 13:39:06.025012
100	EVTPNa	https://example.com/	0	2026-11-17 13:39:06.179577
101	F5z0lj	https://example.com/	0	2026-11-17 13:39:06.342629
\.


--
-- Name: urls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: shortener_user
--

SELECT pg_catalog.setval('public.urls_id_seq', 101, true);


--
-- Name: urls urls_pkey; Type: CONSTRAINT; Schema: public; Owner: shortener_user
--

ALTER TABLE ONLY public.urls
    ADD CONSTRAINT urls_pkey PRIMARY KEY (id);


--
-- Name: urls urls_short_code_key; Type: CONSTRAINT; Schema: public; Owner: shortener_user
--

ALTER TABLE ONLY public.urls
    ADD CONSTRAINT urls_short_code_key UNIQUE (short_code);


--
-- PostgreSQL database dump complete
--

\unrestrict TLdF7umSgJRuaglKt9wyHOZZWFfgMIhAisfmSaJajAEyTuYRS5PGtmKLH8HCXMC

